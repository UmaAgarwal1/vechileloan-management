package com.appvehicle.dto;

public class AdminDto  {
	private String email;
	private String name;
	private String password;

}
