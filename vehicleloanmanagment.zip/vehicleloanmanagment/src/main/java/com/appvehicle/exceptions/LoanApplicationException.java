package com.appvehicle.exceptions;



public class LoanApplicationException extends Exception {
    public LoanApplicationException(String message)
    {
        super(message);
    }

 

}