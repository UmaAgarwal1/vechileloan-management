package com.vehicleloanapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleloanmanagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
